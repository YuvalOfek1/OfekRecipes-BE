package com.example.ofek_recipes.controllers;

import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ErrorHandler {

}
